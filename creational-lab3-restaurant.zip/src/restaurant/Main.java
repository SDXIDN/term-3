package restaurant;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/** Демонстрація породжувальних шаблонів: Singleton і Prototype. */
public class Main {
    public static void main(String[] args) throws Exception {
        System.out.println("===== SINGLETON =====");
        RestaurantConfig c1 = RestaurantConfig.getInstance();
        RestaurantConfig c2 = RestaurantConfig.getInstance();
        System.out.println("c1 == c2: " + (c1 == c2));
        System.out.println("AuditLog.INSTANCE == AuditLog.INSTANCE: " + (AuditLog.INSTANCE == AuditLog.INSTANCE));

        // Перевірка потокобезпеки: 8 потоків одночасно беруть екземпляр
        Set<RestaurantConfig> unique = ConcurrentHashMap.newKeySet();
        Thread[] threads = new Thread[8];
        for (int i = 0; i < threads.length; i++) {
            threads[i] = new Thread(() -> unique.add(RestaurantConfig.getInstance()));
            threads[i].start();
        }
        for (Thread t : threads) t.join();
        System.out.println("Унікальних екземплярів RestaurantConfig з 8 потоків: " + unique.size());

        Restaurant restaurant = new Restaurant(c1.getRestaurantName());
        restaurant.addTable(1, 2);
        restaurant.addTable(2, 4);
        restaurant.addVipTable(3, 8, 500);

        ReservationRepository repository = new InMemoryReservationRepository();
        NotificationService notifications = new NotificationService(new SmsSender());
        ReservationService reservationService = new ReservationService(
                restaurant, new ReservationValidator(), repository, notifications);
        BillingService billing = new BillingService(Arrays.asList(
                new LoyaltyDiscount(), new LargeOrderDiscount(), new HappyHourDiscount()));
        BookingController controller = new BookingController(
                reservationService, billing, new CardPayment(), notifications);

        Customer ivan = new Customer("Іван", "+380501112233", true);
        TimeSlot slot = new TimeSlot(LocalDateTime.of(2026, 12, 5, 16, 0), c1.getDefaultSlotMinutes());
        Reservation r1 = controller.reserveTable(ivan, 3, slot);
        controller.reserveTable(ivan, 12, slot); // відхилено: більше ліміту з RestaurantConfig
        System.out.println("Записів в AuditLog: " + AuditLog.INSTANCE.size());

        System.out.println("\n===== PROTOTYPE =====");
        // 1) Реєстр прототипів меню
        MenuPrototypeRegistry registry = new MenuPrototypeRegistry();
        registry.register("borscht", new Dish("Борщ", 120, 350));
        registry.register("wine", new Drink("Вино (келих)", 180, 150, true));

        Dish largeBorscht = (Dish) registry.create("borscht");
        largeBorscht.setName("Борщ (велика порція)");
        largeBorscht.setPrice(180);
        largeBorscht.setWeightGrams(500);
        Dish regularBorscht = (Dish) registry.create("borscht");
        System.out.println("Копія: " + largeBorscht.getName() + ", " + largeBorscht.getPrice() + " грн, "
                + largeBorscht.getWeightGrams() + " г");
        System.out.println("Зразок не змінився: " + regularBorscht.getName() + ", " + regularBorscht.getPrice() + " грн");

        // 2) Клонування замовлення ("повторити замовлення")
        Order original = new Order(r1);
        original.addItem(regularBorscht, 2);
        original.addItem(registry.create("wine"), 2);

        Order clone = original.copy();
        clone.addItem(largeBorscht, 1); // змінюємо лише копію

        System.out.println("Сума оригіналу: " + original.calculateTotal() + ", сума копії: " + clone.calculateTotal());
        System.out.println("Рядки замовлення - різні об'єкти (глибока копія): "
                + (original.getItems().get(0) != clone.getItems().get(0)));
        System.out.println("Позиції меню - різні об'єкти: "
                + (original.getItems().get(0).getMenuItem() != clone.getItems().get(0).getMenuItem()));
        System.out.println("Бронювання - спільне посилання: " + (original.getReservation() == clone.getReservation()));

        // 3) Копія для іншого візиту
        TimeSlot nextVisit = new TimeSlot(LocalDateTime.of(2026, 12, 12, 19, 0), c1.getDefaultSlotMinutes());
        Reservation r2 = controller.reserveTable(ivan, 2, nextVisit);
        Order repeat = original.copyFor(r2);
        System.out.println("Повторне замовлення на інший візит, сума: " + repeat.calculateTotal());
        controller.checkout(repeat);
    }
}
