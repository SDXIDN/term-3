# ЛР №3. Породжувальні шаблони: Singleton і Prototype

Розширення проєкту з ЛР №1 (GRASP) і ЛР №2 (SOLID) на тій самій предметній області «Бронювання столиків і харчування».

Компіляція: `javac -encoding UTF-8 -d out src/restaurant/*.java`
Запуск: `java -Dfile.encoding=UTF-8 -cp out restaurant.Main`
Javadoc: `javadoc -encoding UTF-8 -charset UTF-8 -private -d docs src/restaurant/*.java`

## Singleton
| Клас | Варіант | Призначення |
|---|---|---|
| RestaurantConfig | Initialization-on-demand holder (лінива, потокобезпечна ініціалізація без synchronized) | Глобальні налаштування: назва закладу, ліміт гостей, тривалість бронювання |
| AuditLog | enum-синглтон (захист від рефлексії та серіалізації) | Журнал аудиту подій |

Використання: ReservationValidator читає ліміт гостей з RestaurantConfig; ReservationService пише події в AuditLog.
Потокобезпеку перевірено в Main: 8 потоків отримують один і той самий екземпляр.

## Prototype
| Клас | Роль |
|---|---|
| Prototype<T> | Інтерфейс з методом copy() |
| MenuItem, Dish, Drink | Конкретні прототипи (коваріантні copy()) |
| OrderItem, Order | Глибоке копіювання замовлення (copy(), copyFor(reservation)) |
| MenuPrototypeRegistry | Реєстр іменованих зразків меню; create(key) повертає копію |

Сценарії в Main: варіація страви («Борщ (велика порція)») без зміни зразка; повторне замовлення з додаванням позиції лише в копію; перенесення замовлення на інше бронювання.

## Зауваження
Singleton створює приховану глобальну залежність і ускладнює тестування та суперечить DIP (ЛР №2),
тому його застосовано лише для інфраструктурних об'єктів (конфігурація, журнал), а не для доменної логіки.
