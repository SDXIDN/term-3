# ЛР №4. Породжувальні шаблони: Factory Method і Abstract Factory

Розширення проєкту з ЛР №1-3 на тій самій предметній області «Бронювання столиків і харчування».

Компіляція: `javac -encoding UTF-8 -d out src/restaurant/*.java`
Запуск: `java -Dfile.encoding=UTF-8 -cp out restaurant.Main`
Javadoc: `javadoc -encoding UTF-8 -charset UTF-8 -private -d docs src/restaurant/*.java`

## Factory Method
| Роль | Оплата | Сповіщення |
|---|---|---|
| Продукт (інтерфейс) | PaymentGateway | NotificationSender |
| Конкретні продукти | CardPayment, CashPayment | SmsSender, TelegramSender, PushSender |
| Творець (абстрактний) | PaymentCreator.createGateway() | NotificationSenderCreator.createSender() |
| Конкретні творці | CardPaymentCreator, CashPaymentCreator | SmsSenderCreator, TelegramSenderCreator, PushSenderCreator |

Спільна логіка творця (PaymentCreator.processPayment, NotificationSenderCreator.createNotificationService) працює лише з абстрактним продуктом.

## Abstract Factory
| Роль | Класи |
|---|---|
| Абстрактна фабрика | VenueFactory |
| Конкретні фабрики (сім'ї) | FineDiningFactory, CasualCafeFactory |
| Абстрактні продукти | Table, Dish, Drink, DiscountPolicy |
| Конкретні продукти | VipTable / Table; дорогі / доступні Dish і Drink; NoDiscount / HappyHourDiscount |
| Клієнт | VenueSetup, Main.runVenue (працюють лише з VenueFactory) |

Фабрика гарантує узгодженість сім'ї: ресторан високої кухні отримує VIP-столики, дорогі позиції і не має акцій, кафе отримує звичайні столики, доступні ціни і «щасливі години».

## Зауваження
Фабрики з ЛР №4 не замінюють DIP з ЛР №2: клієнти залежать від абстракцій (PaymentGateway, NotificationSender, VenueFactory), а вибір конкретного творця робить Main (композиційний корінь).
