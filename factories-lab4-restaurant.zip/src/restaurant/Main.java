package restaurant;

import java.time.LocalDateTime;
import java.util.Arrays;

/** Демонстрація породжувальних шаблонів: Factory Method і Abstract Factory. */
public class Main {
    public static void main(String[] args) {
        Customer ivan = new Customer("Іван", "+380501112233", true);

        System.out.println("===== FACTORY METHOD: способи оплати =====");
        PaymentCreator[] payments = { new CardPaymentCreator(), new CashPaymentCreator() };
        for (PaymentCreator creator : payments) {
            creator.processPayment(ivan, 500);   // клієнт не знає, який саме продукт створюється
        }

        System.out.println("\n===== FACTORY METHOD: канали сповіщень =====");
        NotificationSenderCreator[] senders = {
                new SmsSenderCreator(), new TelegramSenderCreator(), new PushSenderCreator() };
        for (NotificationSenderCreator creator : senders) {
            creator.createNotificationService().notifyPaid(ivan, 500);
        }

        System.out.println("\n===== ABSTRACT FACTORY: формати закладів =====");
        runVenue("Ресторан «Ліра»", new FineDiningFactory(),
                ivan, new TelegramSenderCreator(), new CardPaymentCreator());
        runVenue("Кафе «Затишок»", new CasualCafeFactory(),
                ivan, new SmsSenderCreator(), new CashPaymentCreator());
    }

    /** Один і той самий клієнтський код працює з будь-якою фабрикою сім'ї продуктів. */
    private static void runVenue(String title, VenueFactory factory, Customer customer,
                                 NotificationSenderCreator senderCreator, PaymentCreator paymentCreator) {
        System.out.println("\n--- " + title + " ---");
        Restaurant restaurant = new Restaurant(title);
        VenueSetup.populate(restaurant, factory, 2, 4, 8);

        for (Table t : restaurant.getTables()) {
            System.out.println("Столик №" + t.getNumber() + " (" + t.getSeats() + " місць): "
                    + t.getClass().getSimpleName());
        }
        for (MenuItem m : restaurant.getMenu()) {
            System.out.println("Меню: " + m.getName() + " - " + m.getPrice() + " грн");
        }

        BillingService billing = new BillingService(Arrays.asList(
                new LoyaltyDiscount(), new LargeOrderDiscount(), factory.createDiscountPolicy()));
        NotificationService notifications = senderCreator.createNotificationService();
        ReservationService reservations = new ReservationService(
                restaurant, new ReservationValidator(), new InMemoryReservationRepository(), notifications);
        BookingController controller = new BookingController(
                reservations, billing, paymentCreator.createGateway(), notifications);

        TimeSlot slot = new TimeSlot(LocalDateTime.of(2026, 12, 5, 16, 0),
                RestaurantConfig.getInstance().getDefaultSlotMinutes());
        Reservation reservation = controller.reserveTable(customer, 3, slot);

        Order order = new Order(reservation);
        order.addItem(factory.createMainDish(), 2);
        order.addItem(factory.createDrink(), 3);
        double amount = controller.checkout(order);
        System.out.printf("Підсумок для закладу \"%s\": %.2f грн%n", title, amount);
    }
}
