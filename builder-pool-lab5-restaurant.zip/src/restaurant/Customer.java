package restaurant;

/** Клієнт закладу. Зберігає контактні дані та рівень лояльності (використовується політикою знижок). */
public class Customer {
    private final String name;
    private final String phone;
    private final boolean loyal;

    public Customer(String name, String phone, boolean loyal) {
        this.name = name;
        this.phone = phone;
        this.loyal = loyal;
    }

    public String getName() { return name; }
    public String getPhone() { return phone; }
    public boolean isLoyal() { return loyal; }
}
