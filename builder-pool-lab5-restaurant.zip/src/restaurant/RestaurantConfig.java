package restaurant;

/**
 * Singleton (Initialization-on-demand holder): глобальна конфігурація закладу.
 * <ul>
 *   <li>Єдиний екземпляр: приватний конструктор + статичний вкладений клас-тримач.</li>
 *   <li>Лінива ініціалізація: екземпляр створюється при першому виклику {@link #getInstance()}.</li>
 *   <li>Потокобезпека гарантується механізмом завантаження класів JVM, без synchronized.</li>
 * </ul>
 */
public final class RestaurantConfig {
    private final String restaurantName;
    private final int maxGuestsPerReservation;
    private final int defaultSlotMinutes;

    private RestaurantConfig() {
        System.out.println("[RestaurantConfig] ініціалізація (виконується один раз)");
        // у реальній системі тут було б читання з файлу/БД; зараз заглушка зі значеннями за замовчуванням
        this.restaurantName = "Смак Буковини";
        this.maxGuestsPerReservation = 10;
        this.defaultSlotMinutes = 120;
    }

    private static final class Holder {
        private static final RestaurantConfig INSTANCE = new RestaurantConfig();
    }

    /** @return єдиний екземпляр конфігурації. */
    public static RestaurantConfig getInstance() { return Holder.INSTANCE; }

    public String getRestaurantName() { return restaurantName; }
    public int getMaxGuestsPerReservation() { return maxGuestsPerReservation; }
    public int getDefaultSlotMinutes() { return defaultSlotMinutes; }
}
