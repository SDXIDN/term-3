package restaurant;

/** Factory Method: конкретний творець, що створює {@link CardPayment}. */
public class CardPaymentCreator extends PaymentCreator {
    @Override public PaymentGateway createGateway() { return new CardPayment(); }
}
