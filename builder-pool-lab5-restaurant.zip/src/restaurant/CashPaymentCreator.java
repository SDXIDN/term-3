package restaurant;

/** Factory Method: конкретний творець, що створює {@link CashPayment}. */
public class CashPaymentCreator extends PaymentCreator {
    @Override public PaymentGateway createGateway() { return new CashPayment(); }
}
