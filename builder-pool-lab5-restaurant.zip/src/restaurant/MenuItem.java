package restaurant;

/** Позиція меню (страва або напій). Prototype: вміє копіювати себе. */
public class MenuItem implements Prototype<MenuItem> {
    private String name;
    private double price;

    public MenuItem(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() { return name; }
    public double getPrice() { return price; }
    public void setName(String name) { this.name = name; }
    public void setPrice(double price) { this.price = price; }

    @Override
    public MenuItem copy() { return new MenuItem(name, price); }
}
