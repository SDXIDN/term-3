package restaurant;

import java.time.LocalDateTime;
import java.util.Arrays;

/** Демонстрація породжувальних шаблонів: Builder і Object Pool. */
public class Main {
    public static void main(String[] args) throws Exception {
        Customer ivan = new Customer("Іван", "+380501112233", true);

        VenueFactory factory = new FineDiningFactory();
        Restaurant restaurant = new Restaurant("Ресторан «Ліра»");
        VenueSetup.populate(restaurant, factory, 2, 4, 8);

        ObjectPool<PaymentTerminal> terminalPool = new ObjectPool<>(PaymentTerminal::new, PaymentTerminal::reset, 2);
        PaymentCreator terminalCreator = new TerminalPaymentCreator(terminalPool);

        NotificationService notifications = new TelegramSenderCreator().createNotificationService();
        BillingService billing = new BillingService(Arrays.asList(new LoyaltyDiscount(), new LargeOrderDiscount()));
        ReservationService reservations = new ReservationService(
                restaurant, new ReservationValidator(), new InMemoryReservationRepository(), notifications);
        BookingController controller = new BookingController(
                reservations, billing, terminalCreator.createGateway(), notifications);

        System.out.println("===== BUILDER: запит на бронювання =====");
        TimeSlot slot = new TimeSlot(LocalDateTime.of(2026, 12, 5, 19, 0),
                RestaurantConfig.getInstance().getDefaultSlotMinutes());

        ReservationRequest custom = new ReservationRequestBuilder()
                .customer(ivan).guests(4).slot(slot)
                .occasion("ювілей").childSeats(1).windowSeat(true).notes("Торт принесемо самі")
                .build();
        System.out.println(custom);
        Reservation r1 = controller.reserveTable(custom);

        ReservationRequestDirector director = new ReservationRequestDirector(new ReservationRequestBuilder());
        ReservationRequest birthday = director.birthday(ivan, 6, slot);
        System.out.println(birthday);
        controller.reserveTable(birthday);

        try {
            new ReservationRequestBuilder().customer(ivan).guests(0).slot(slot).build();
        } catch (IllegalStateException e) {
            System.out.println("Builder відхилив некоректний запит: " + e.getMessage());
        }

        System.out.println("\n===== BUILDER: замовлення =====");
        Order order = new OrderBuilder()
                .forReservation(r1)
                .item(factory.createMainDish(), 2)
                .item(factory.createDrink(), 4)
                .build();

        System.out.println("\n===== OBJECT POOL: послідовні платежі =====");
        controller.checkout(order);
        for (int i = 0; i < 3; i++) {
            terminalCreator.processPayment(ivan, 100 + i);
        }
        System.out.println("Створено терміналів: " + terminalPool.getCreatedCount()
                + ", вільних: " + terminalPool.getIdleCount());

        System.out.println("\n===== OBJECT POOL: паралельні платежі (4 потоки, ліміт 2 термінали) =====");
        Thread[] threads = new Thread[4];
        for (int i = 0; i < threads.length; i++) {
            final int n = i + 1;
            threads[i] = new Thread(() -> terminalCreator.processPayment(ivan, 200 + n), "потік-" + n);
            threads[i].start();
        }
        for (Thread t : threads) t.join();
        System.out.println("Створено терміналів: " + terminalPool.getCreatedCount()
                + ", вільних: " + terminalPool.getIdleCount());
    }
}
