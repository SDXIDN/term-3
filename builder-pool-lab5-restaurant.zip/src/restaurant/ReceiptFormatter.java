package restaurant;

/**
 * SRP: єдина відповідальність - сформувати текст чека.
 * Не рахує суми (це {@link BillingService}) і не друкує (це справа викликача).
 */
public class ReceiptFormatter {
    public String format(Order order, double finalAmount) {
        StringBuilder sb = new StringBuilder();
        sb.append("=== ЧЕК ===\n");
        sb.append("Клієнт: ").append(order.getReservation().getCustomer().getName()).append('\n');
        sb.append("Столик: ").append(order.getReservation().getTable().getNumber()).append('\n');
        for (OrderItem i : order.getItems()) {
            sb.append(String.format("%-14s x%d  %8.2f%n",
                    i.getMenuItem().getName(), i.getQuantity(), i.getSubtotal()));
        }
        sb.append(String.format("До сплати: %.2f грн%n", finalAmount));
        return sb.toString();
    }
}
