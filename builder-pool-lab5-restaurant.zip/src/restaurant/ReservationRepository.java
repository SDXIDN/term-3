package restaurant;

/** DIP: абстракція сховища бронювань. Високорівневі класи залежать від неї, а не від конкретної БД. */
public interface ReservationRepository extends ReservationReader, ReservationWriter {
}
