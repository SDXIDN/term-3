package restaurant;

/** ISP: інтерфейс лише для запису бронювань. */
public interface ReservationWriter {
    void save(Reservation reservation);
}
