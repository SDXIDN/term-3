package restaurant;

/**
 * Pure Fabrication: допоміжний клас-клієнт абстрактної фабрики. Наповнює заклад продуктами
 * однієї сім'ї й працює виключно з інтерфейсом {@link VenueFactory} (DIP).
 */
public final class VenueSetup {
    private VenueSetup() { }

    /** Створює столики (за переліком місць) і базове меню за допомогою переданої фабрики. */
    public static void populate(Restaurant restaurant, VenueFactory factory, int... seatsPerTable) {
        int number = 1;
        for (int seats : seatsPerTable) {
            restaurant.addTable(factory.createTable(number++, seats));
        }
        restaurant.addMenuItem(factory.createMainDish());
        restaurant.addMenuItem(factory.createDrink());
    }
}
