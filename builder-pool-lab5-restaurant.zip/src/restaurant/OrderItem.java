package restaurant;

/**
 * Рядок замовлення. Створюється лише класом {@link Order} (GRASP Creator).
 * Prototype: копія містить власну копію позиції меню (глибоке копіювання).
 */
public class OrderItem implements Prototype<OrderItem> {
    private final MenuItem menuItem;
    private final int quantity;

    OrderItem(MenuItem menuItem, int quantity) { // package-private: створює лише Order
        this.menuItem = menuItem;
        this.quantity = quantity;
    }

    public MenuItem getMenuItem() { return menuItem; }
    public int getQuantity() { return quantity; }

    /** Information Expert: ціна й кількість лежать у цьому класі. */
    public double getSubtotal() { return menuItem.getPrice() * quantity; }

    @Override
    public OrderItem copy() { return new OrderItem(menuItem.copy(), quantity); }
}
