package restaurant;

import java.util.HashMap;
import java.util.Map;

/**
 * Prototype Registry: зберігає іменовані зразки позицій меню й видає їхні копії.
 * Дозволяє швидко створювати варіації ("велика порція", "дитяча порція") без прямого виклику конструкторів.
 */
public class MenuPrototypeRegistry {
    private final Map<String, MenuItem> prototypes = new HashMap<>();

    public void register(String key, MenuItem prototype) {
        System.out.println("[MenuPrototypeRegistry.register] key=" + key);
        prototypes.put(key, prototype);
    }

    /** @return нова копія зразка; сам зразок не змінюється. */
    public MenuItem create(String key) {
        MenuItem prototype = prototypes.get(key);
        if (prototype == null) {
            throw new IllegalArgumentException("Невідомий прототип: " + key);
        }
        return prototype.copy();
    }
}
