package restaurant;

/** Страва. Prototype: перевизначає copy() з коваріантним типом, що повертається ({@link Dish}). */
public class Dish extends MenuItem {
    private int weightGrams;

    public Dish(String name, double price, int weightGrams) {
        super(name, price);
        this.weightGrams = weightGrams;
    }

    public int getWeightGrams() { return weightGrams; }
    public void setWeightGrams(int weightGrams) { this.weightGrams = weightGrams; }

    @Override
    public Dish copy() { return new Dish(getName(), getPrice(), weightGrams); }
}
