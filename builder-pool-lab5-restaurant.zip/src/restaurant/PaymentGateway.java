package restaurant;

/**
 * Protected Variations: точка нестабільності (спосіб оплати) захована за стабільним інтерфейсом.
 * Додавання нового способу оплати не змінює решту системи.
 */
public interface PaymentGateway {
    void pay(Customer customer, double amount);
}
