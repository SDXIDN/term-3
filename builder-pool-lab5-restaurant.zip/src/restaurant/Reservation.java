package restaurant;

/** Бронювання столика клієнтом на певний час. */
public class Reservation {
    private final Customer customer;
    private final Table table;
    private final TimeSlot slot;
    private final int guests;

    public Reservation(Customer customer, Table table, TimeSlot slot, int guests) {
        this.customer = customer;
        this.table = table;
        this.slot = slot;
        this.guests = guests;
    }

    public Customer getCustomer() { return customer; }
    public Table getTable() { return table; }
    public TimeSlot getSlot() { return slot; }
    public int getGuests() { return guests; }
}
