package restaurant;

/**
 * Factory Method: абстрактний творець каналів сповіщень.
 * {@link #createSender()} - фабричний метод; {@link #createNotificationService()} збирає з його продукту сервіс.
 */
public abstract class NotificationSenderCreator {

    /** Фабричний метод: підклас повертає конкретний канал. */
    public abstract NotificationSender createSender();

    /** Спільна логіка творця, що не залежить від конкретного каналу. */
    public NotificationService createNotificationService() {
        return new NotificationService(createSender());
    }
}
