package restaurant;

/**
 * Director (Builder): знає типові послідовності кроків побудови й інкапсулює готові сценарії бронювання.
 * Клієнтський код отримує готовий запит однією дією, не повторюючи налаштування.
 */
public class ReservationRequestDirector {
    private final ReservationRequestBuilder builder;

    public ReservationRequestDirector(ReservationRequestBuilder builder) { this.builder = builder; }

    /** Святкування дня народження: VIP-столик, дитячі стільці, нотатка про торт. */
    public ReservationRequest birthday(Customer customer, int guests, TimeSlot slot) {
        return builder.reset().customer(customer).guests(guests).slot(slot)
                .occasion("день народження").childSeats(2).vipOnly(true)
                .notes("Торт і свічки до приходу гостей").build();
    }

    /** Діловий обід: без дітей, тихий столик біля вікна. */
    public ReservationRequest businessLunch(Customer customer, int guests, TimeSlot slot) {
        return builder.reset().customer(customer).guests(guests).slot(slot)
                .occasion("діловий обід").windowSeat(true).notes("Тихий столик, рахунок одним чеком").build();
    }

    /** Романтична вечеря удвох. */
    public ReservationRequest romanticDinner(Customer customer, TimeSlot slot) {
        return builder.reset().customer(customer).guests(2).slot(slot)
                .occasion("романтична вечеря").windowSeat(true).vipOnly(true).notes("Свічки на столі").build();
    }
}
