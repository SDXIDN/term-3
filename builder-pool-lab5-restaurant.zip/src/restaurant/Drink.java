package restaurant;

/** Напій. Prototype: перевизначає copy() з коваріантним типом, що повертається ({@link Drink}). */
public class Drink extends MenuItem {
    private int volumeMl;
    private final boolean alcoholic;

    public Drink(String name, double price, int volumeMl, boolean alcoholic) {
        super(name, price);
        this.volumeMl = volumeMl;
        this.alcoholic = alcoholic;
    }

    public int getVolumeMl() { return volumeMl; }
    public void setVolumeMl(int volumeMl) { this.volumeMl = volumeMl; }
    public boolean isAlcoholic() { return alcoholic; }

    @Override
    public Drink copy() { return new Drink(getName(), getPrice(), volumeMl, alcoholic); }
}
