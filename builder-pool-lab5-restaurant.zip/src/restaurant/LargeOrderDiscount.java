package restaurant;

/** Знижка 5% для замовлень від 1000 грн. */
public class LargeOrderDiscount implements DiscountPolicy {
    @Override public double discount(Order order) {
        return order.calculateTotal() >= 1000 ? order.calculateTotal() * 0.05 : 0;
    }
}
