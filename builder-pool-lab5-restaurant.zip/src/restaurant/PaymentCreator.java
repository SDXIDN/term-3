package restaurant;

/**
 * Factory Method: абстрактний творець (Creator) способів оплати.
 * Фабричний метод {@link #createGateway()} перекладає вибір конкретного {@link PaymentGateway} на підкласи,
 * а спільний алгоритм {@link #processPayment(Customer, double)} працює лише з абстрактним продуктом.
 */
public abstract class PaymentCreator {

    /** Фабричний метод: підклас вирішує, який саме спосіб оплати створити. */
    public abstract PaymentGateway createGateway();

    /** Шаблонна операція, що використовує фабричний метод і не знає конкретного класу продукту. */
    public void processPayment(Customer customer, double amount) {
        PaymentGateway gateway = createGateway();
        AuditLog.INSTANCE.log("Оплата через " + gateway.getClass().getSimpleName() + ", сума " + amount);
        gateway.pay(customer, amount);
    }
}
