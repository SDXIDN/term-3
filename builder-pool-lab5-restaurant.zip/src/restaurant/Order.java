package restaurant;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Замовлення харчування, прив'язане до бронювання.
 * <ul>
 *   <li>Creator: агрегує та створює {@link OrderItem}.</li>
 *   <li>Information Expert: має всі рядки, тож сам рахує суму.</li>
 *   <li>Prototype: підтримує клонування ("повторити замовлення") з глибокою копією рядків.</li>
 * </ul>
 */
public class Order implements Prototype<Order> {
    private final Reservation reservation;
    private final List<OrderItem> items = new ArrayList<>();

    public Order(Reservation reservation) { this.reservation = reservation; }

    /** Creator: Order агрегує OrderItem, тому відповідає за їх створення. */
    public void addItem(MenuItem menuItem, int quantity) {
        System.out.println("[Order.addItem] " + menuItem.getName() + " x" + quantity);
        items.add(new OrderItem(menuItem, quantity));
    }

    /** Information Expert: сума замовлення без знижок. */
    public double calculateTotal() {
        double total = 0;
        for (OrderItem item : items) total += item.getSubtotal();
        return total;
    }

    public Reservation getReservation() { return reservation; }
    public List<OrderItem> getItems() { return Collections.unmodifiableList(items); }

    /** Глибока копія для того самого бронювання (бронювання - спільне посилання, це свідомо). */
    @Override
    public Order copy() { return copyFor(reservation); }

    /** Глибока копія замовлення, прив'язана до іншого бронювання (повторне замовлення в інший візит). */
    public Order copyFor(Reservation newReservation) {
        Order clone = new Order(newReservation);
        for (OrderItem item : items) clone.items.add(item.copy());
        return clone;
    }
}
