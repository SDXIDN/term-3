package restaurant;

import java.util.List;

/** ISP: інтерфейс лише для читання бронювань (звіти, перегляд). */
public interface ReservationReader {
    List<Reservation> findByCustomer(Customer customer);
}
