package restaurant;

/** Без знижки. */
public class NoDiscount implements DiscountPolicy {
    @Override public double discount(Order order) { return 0; }
}
