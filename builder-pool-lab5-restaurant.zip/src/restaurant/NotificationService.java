package restaurant;

/**
 * Indirection: посередник між бізнес-логікою та каналами сповіщень.
 * Контролер не знає, SMS це, email чи push.
 */
public class NotificationService {
    private final NotificationSender sender;

    public NotificationService(NotificationSender sender) { this.sender = sender; }

    public void notifyReservationConfirmed(Reservation r) {
        sender.send(r.getCustomer().getPhone(),
                "Столик №" + r.getTable().getNumber() + " заброньовано на " + r.getSlot());
    }

    public void notifyPaid(Customer c, double amount) {
        sender.send(c.getPhone(), "Оплату " + String.format("%.2f", amount) + " грн отримано");
    }
}
