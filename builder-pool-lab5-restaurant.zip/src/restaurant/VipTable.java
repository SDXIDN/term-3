package restaurant;

/**
 * VIP-столик. LSP: повністю підміняє {@link Table} (ті самі передумови й постумови isAvailable),
 * лише додає власну властивість - депозит. Клієнтський код працює з Table і не помічає різниці.
 */
public class VipTable extends Table {
    private final double deposit;

    public VipTable(int number, int seats, double deposit) {
        super(number, seats);
        this.deposit = deposit;
    }

    public double getDeposit() { return deposit; }
}
