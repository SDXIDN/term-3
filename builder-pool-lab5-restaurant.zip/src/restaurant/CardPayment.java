package restaurant;

/** Оплата карткою (заглушка). ISP: реалізує і {@link PaymentGateway}, і {@link Refundable}. */
public class CardPayment implements PaymentGateway, Refundable {
    @Override public void pay(Customer customer, double amount) {
        System.out.printf("[CardPayment.pay] customer=%s, amount=%.2f%n", customer.getName(), amount);
    }

    @Override public void refund(Customer customer, double amount) {
        System.out.printf("[CardPayment.refund] customer=%s, amount=%.2f%n", customer.getName(), amount);
    }
}
