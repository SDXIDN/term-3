package restaurant;

import java.util.List;

/**
 * Pure Fabrication: у предметній області немає «калькулятора рахунків»,
 * але винесення розрахунку сюди підвищує High Cohesion класу Order
 * і дозволяє комбінувати {@link DiscountPolicy} (Polymorphism).
 */
public class BillingService {
    private final List<DiscountPolicy> policies;

    public BillingService(List<DiscountPolicy> policies) { this.policies = policies; }

    public double calculateFinalAmount(Order order) {
        double total = order.calculateTotal();
        double discount = 0;
        for (DiscountPolicy p : policies) discount += p.discount(order);
        System.out.printf("[BillingService] total=%.2f, discount=%.2f%n", total, discount);
        return total - discount;
    }
}
