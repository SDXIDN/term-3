package restaurant;

import java.time.LocalDateTime;

/** Часовий проміжок бронювання. Інформаційний експерт щодо перетину інтервалів. */
public class TimeSlot {
    private final LocalDateTime start;
    private final LocalDateTime end;

    public TimeSlot(LocalDateTime start, int durationMinutes) {
        this.start = start;
        this.end = start.plusMinutes(durationMinutes);
    }

    public LocalDateTime getStart() { return start; }

    /** @return true, якщо проміжки перетинаються. */
    public boolean overlaps(TimeSlot other) {
        return start.isBefore(other.end) && other.start.isBefore(end);
    }

    @Override
    public String toString() { return start + " - " + end.toLocalTime(); }
}
