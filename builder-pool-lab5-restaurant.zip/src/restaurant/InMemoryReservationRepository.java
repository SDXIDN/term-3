package restaurant;

import java.util.ArrayList;
import java.util.List;

/** DIP: низькорівнева деталь (зберігання в пам'яті). Її можна замінити на JDBC/JPA без змін у сервісах. */
public class InMemoryReservationRepository implements ReservationRepository {
    private final List<Reservation> storage = new ArrayList<>();

    @Override public void save(Reservation reservation) {
        System.out.println("[InMemoryReservationRepository.save] table=" + reservation.getTable().getNumber());
        storage.add(reservation);
    }

    @Override public List<Reservation> findByCustomer(Customer customer) {
        List<Reservation> result = new ArrayList<>();
        for (Reservation r : storage) {
            if (r.getCustomer() == customer) result.add(r);
        }
        return result;
    }
}
