package restaurant;

/** Abstract Factory: конкретна фабрика формату "демократичне кафе" (прості столики, доступні ціни, щасливі години). */
public class CasualCafeFactory implements VenueFactory {
    @Override public Table createTable(int number, int seats) { return new Table(number, seats); }
    @Override public Dish createMainDish() { return new Dish("Бургер", 220, 250); }
    @Override public Drink createDrink() { return new Drink("Лимонад", 70, 300, false); }
    @Override public DiscountPolicy createDiscountPolicy() { return new HappyHourDiscount(); }
}
