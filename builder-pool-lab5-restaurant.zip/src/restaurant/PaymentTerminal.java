package restaurant;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Платіжний POS-термінал: обмежений ресурс, ініціалізація якого дорога (з'єднання, ключі).
 * Саме тому термінали зберігаються в {@link ObjectPool} і використовуються повторно.
 */
public class PaymentTerminal {
    private static final AtomicInteger SEQUENCE = new AtomicInteger();

    private final int id;
    private Customer lastCustomer;

    public PaymentTerminal() {
        this.id = SEQUENCE.incrementAndGet();
        System.out.println("[PaymentTerminal] ініціалізація терміналу #" + id + " (дорога операція)");
        pause(100);
    }

    /** Обробка платежу (заглушка з імітацією тривалості). */
    public void process(Customer customer, double amount) {
        lastCustomer = customer;
        System.out.printf("[PaymentTerminal#%d.process] customer=%s, amount=%.2f%n", id, customer.getName(), amount);
        pause(150);
    }

    /** Очищає стан терміналу перед поверненням у пул. */
    public void reset() { lastCustomer = null; }

    public int getId() { return id; }

    private static void pause(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
