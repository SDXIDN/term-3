package restaurant;

/** Factory Method: створює {@link PushSender}. */
public class PushSenderCreator extends NotificationSenderCreator {
    @Override public NotificationSender createSender() { return new PushSender(); }
}
