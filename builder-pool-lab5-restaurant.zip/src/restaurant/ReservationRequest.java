package restaurant;

/**
 * Builder: складний продукт - запит на бронювання з багатьма необов'язковими параметрами.
 * Незмінний (immutable), створюється лише через {@link ReservationRequestBuilder}.
 */
public class ReservationRequest {
    private final Customer customer;
    private final int guests;
    private final TimeSlot slot;
    private final String occasion;
    private final int childSeats;
    private final boolean windowSeat;
    private final boolean vipOnly;
    private final String notes;

    ReservationRequest(ReservationRequestBuilder b) { // package-private: лише білдер
        this.customer = b.customer;
        this.guests = b.guests;
        this.slot = b.slot;
        this.occasion = b.occasion;
        this.childSeats = b.childSeats;
        this.windowSeat = b.windowSeat;
        this.vipOnly = b.vipOnly;
        this.notes = b.notes;
    }

    public Customer getCustomer() { return customer; }
    public int getGuests() { return guests; }
    public TimeSlot getSlot() { return slot; }
    public String getOccasion() { return occasion; }
    public int getChildSeats() { return childSeats; }
    public boolean isWindowSeat() { return windowSeat; }
    public boolean isVipOnly() { return vipOnly; }
    public String getNotes() { return notes; }

    @Override
    public String toString() {
        return "ReservationRequest{клієнт=" + customer.getName() + ", гостей=" + guests + ", привід=" + occasion
                + ", дитячих стільців=" + childSeats + ", біля вікна=" + windowSeat + ", лише VIP=" + vipOnly
                + ", нотатки='" + notes + "'}";
    }
}
