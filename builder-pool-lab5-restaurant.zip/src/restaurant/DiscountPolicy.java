package restaurant;

/** Polymorphism: спільний інтерфейс для різних правил знижок. */
public interface DiscountPolicy {
    /** @return розмір знижки в грошах для даного замовлення. */
    double discount(Order order);
}
