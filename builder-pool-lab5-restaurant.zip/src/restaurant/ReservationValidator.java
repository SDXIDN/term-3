package restaurant;

/** SRP: перевірка коректності запиту на бронювання. Ліміт гостей береться з {@link RestaurantConfig} (Singleton). */
public class ReservationValidator {
    public boolean isValid(int guests, TimeSlot slot) {
        int max = RestaurantConfig.getInstance().getMaxGuestsPerReservation();
        boolean ok = guests > 0 && guests <= max && slot != null;
        System.out.println("[ReservationValidator.isValid] guests=" + guests + " (max " + max + ") -> " + ok);
        return ok;
    }
}
