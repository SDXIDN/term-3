package restaurant;

/**
 * Спосіб оплати через термінал із пулу. Бере термінал, виконує платіж і гарантовано повертає його (finally).
 * Protected Variations: для решти системи це звичайний {@link PaymentGateway}.
 */
public class TerminalPaymentGateway implements PaymentGateway {
    private final ObjectPool<PaymentTerminal> pool;

    public TerminalPaymentGateway(ObjectPool<PaymentTerminal> pool) { this.pool = pool; }

    @Override public void pay(Customer customer, double amount) {
        PaymentTerminal terminal = pool.acquire();
        try {
            terminal.process(customer, amount);
        } finally {
            pool.release(terminal);
        }
    }
}
