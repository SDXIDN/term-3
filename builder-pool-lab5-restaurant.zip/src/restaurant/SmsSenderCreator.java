package restaurant;

/** Factory Method: створює {@link SmsSender}. */
public class SmsSenderCreator extends NotificationSenderCreator {
    @Override public NotificationSender createSender() { return new SmsSender(); }
}
