package restaurant;

/** Factory Method: створює {@link TelegramSender}. */
public class TelegramSenderCreator extends NotificationSenderCreator {
    @Override public NotificationSender createSender() { return new TelegramSender(); }
}
