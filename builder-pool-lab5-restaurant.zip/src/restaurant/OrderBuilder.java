package restaurant;

import java.util.ArrayList;
import java.util.List;

/** Builder: покроково збирає {@link Order} з бронювання та позицій меню (fluent-інтерфейс). */
public class OrderBuilder {
    private static final class Line {
        final MenuItem item;
        final int quantity;
        Line(MenuItem item, int quantity) { this.item = item; this.quantity = quantity; }
    }

    private Reservation reservation;
    private final List<Line> lines = new ArrayList<>();

    public OrderBuilder forReservation(Reservation reservation) { this.reservation = reservation; return this; }

    public OrderBuilder item(MenuItem item, int quantity) {
        if (quantity <= 0) throw new IllegalArgumentException("Кількість має бути додатною");
        lines.add(new Line(item, quantity));
        return this;
    }

    /** @throws IllegalStateException якщо немає бронювання або жодної позиції */
    public Order build() {
        if (reservation == null) throw new IllegalStateException("Замовлення має бути прив'язане до бронювання");
        if (lines.isEmpty()) throw new IllegalStateException("Замовлення не може бути порожнім");
        Order order = new Order(reservation);
        for (Line l : lines) order.addItem(l.item, l.quantity);
        return order;
    }
}
