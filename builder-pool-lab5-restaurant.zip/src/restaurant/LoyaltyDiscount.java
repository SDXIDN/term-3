package restaurant;

/** Знижка 10% для лояльних клієнтів. */
public class LoyaltyDiscount implements DiscountPolicy {
    @Override public double discount(Order order) {
        return order.getReservation().getCustomer().isLoyal() ? order.calculateTotal() * 0.10 : 0;
    }
}
