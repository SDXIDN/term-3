package restaurant;

/**
 * ISP: можливість повернення коштів винесена в окремий вузький інтерфейс.
 * Способи оплати, що не підтримують повернення (готівка), його не реалізують
 * і не зобов'язані мати порожній або кидати-виключення метод refund.
 */
public interface Refundable {
    void refund(Customer customer, double amount);
}
