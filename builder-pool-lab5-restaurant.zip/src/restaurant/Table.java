package restaurant;

import java.util.ArrayList;
import java.util.List;

/** Столик. Information Expert: знає власні бронювання, тож сам визначає свою доступність. */
public class Table {
    private final int number;
    private final int seats;
    private final List<Reservation> reservations = new ArrayList<>();

    public Table(int number, int seats) {
        this.number = number;
        this.seats = seats;
    }

    public int getNumber() { return number; }
    public int getSeats() { return seats; }

    /** @return true, якщо столик вільний у заданий проміжок. */
    public boolean isAvailable(TimeSlot slot) {
        for (Reservation r : reservations) {
            if (r.getSlot().overlaps(slot)) return false;
        }
        return true;
    }

    void addReservation(Reservation reservation) { reservations.add(reservation); }
}
