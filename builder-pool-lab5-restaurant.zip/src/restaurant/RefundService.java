package restaurant;

/** ISP + DIP: залежить лише від {@link Refundable}, а не від повного інтерфейсу оплати. */
public class RefundService {
    private final Refundable refundable;

    public RefundService(Refundable refundable) { this.refundable = refundable; }

    public void refundOrder(Customer customer, double amount) {
        System.out.println("[RefundService] повернення коштів за скасоване замовлення");
        refundable.refund(customer, amount);
    }
}
