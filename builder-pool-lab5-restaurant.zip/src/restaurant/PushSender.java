package restaurant;

/** Push-сповіщення в мобільному застосунку (заглушка). */
public class PushSender implements NotificationSender {
    @Override public void send(String recipient, String message) {
        System.out.println("[PushSender.send] device=" + recipient + ", message=" + message);
    }
}
