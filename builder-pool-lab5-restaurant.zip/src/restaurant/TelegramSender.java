package restaurant;

/** Канал Telegram (заглушка). */
public class TelegramSender implements NotificationSender {
    @Override public void send(String recipient, String message) {
        System.out.println("[TelegramSender.send] chat=" + recipient + ", message=" + message);
    }
}
