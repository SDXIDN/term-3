package restaurant;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Object Pool: узагальнений потокобезпечний пул обмежених або "дорогих" у створенні об'єктів.
 * Об'єкти створюються ліниво до ліміту {@code maxSize}, повертаються через {@link #release(Object)}
 * і повторно використовуються. Якщо вільних немає й ліміт вичерпано, потік очікує повернення об'єкта.
 *
 * @param <T> тип об'єктів у пулі
 */
public class ObjectPool<T> {
    private static final long ACQUIRE_TIMEOUT_MS = 3000;

    private final BlockingQueue<T> idle = new LinkedBlockingQueue<>();
    private final Supplier<T> factory;
    private final Consumer<T> resetter;
    private final int maxSize;
    private int created;

    /**
     * @param factory  створює новий об'єкт
     * @param resetter приводить об'єкт у початковий стан перед поверненням у пул
     * @param maxSize  максимальна кількість об'єктів
     */
    public ObjectPool(Supplier<T> factory, Consumer<T> resetter, int maxSize) {
        this.factory = factory;
        this.resetter = resetter;
        this.maxSize = maxSize;
    }

    /** Бере об'єкт із пулу: вільний, новий (якщо не досягнуто ліміт) або чекає на повернення. */
    public T acquire() {
        T obj = idle.poll();
        if (obj != null) {
            System.out.println("[ObjectPool.acquire] повторне використання вільного об'єкта");
            return obj;
        }
        boolean mayCreate;
        synchronized (this) {
            mayCreate = created < maxSize;
            if (mayCreate) created++;
        }
        if (mayCreate) {
            System.out.println("[ObjectPool.acquire] створення нового об'єкта");
            return factory.get();
        }
        System.out.println("[ObjectPool.acquire] ліміт досягнуто, " + Thread.currentThread().getName() + " очікує");
        try {
            obj = idle.poll(ACQUIRE_TIMEOUT_MS, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Очікування об'єкта з пулу перервано", e);
        }
        if (obj == null) throw new IllegalStateException("Таймаут очікування вільного об'єкта з пулу");
        return obj;
    }

    /** Повертає об'єкт у пул після скидання його стану. */
    public void release(T obj) {
        resetter.accept(obj);
        idle.offer(obj);
        System.out.println("[ObjectPool.release] об'єкт повернено в пул");
    }

    /** @return скільки об'єктів створено за весь час. */
    public synchronized int getCreatedCount() { return created; }

    /** @return скільки об'єктів зараз вільні. */
    public int getIdleCount() { return idle.size(); }
}
