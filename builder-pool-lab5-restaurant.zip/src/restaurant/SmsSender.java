package restaurant;

/** SMS-канал (заглушка). */
public class SmsSender implements NotificationSender {
    @Override public void send(String recipient, String message) {
        System.out.println("[SmsSender.send] to=" + recipient + ", message=" + message);
    }
}
