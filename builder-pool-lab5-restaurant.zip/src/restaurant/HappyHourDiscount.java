package restaurant;

/**
 * OCP: нова політика знижок "щасливі години" (15:00-17:00, 15%).
 * Додана як окремий клас - {@link BillingService}, {@link DiscountPolicy} та інші класи НЕ змінювались.
 */
public class HappyHourDiscount implements DiscountPolicy {
    @Override public double discount(Order order) {
        int hour = order.getReservation().getSlot().getStart().getHour();
        return (hour >= 15 && hour < 17) ? order.calculateTotal() * 0.15 : 0;
    }
}
