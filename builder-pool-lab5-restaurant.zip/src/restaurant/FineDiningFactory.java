package restaurant;

/** Abstract Factory: конкретна фабрика формату "ресторан високої кухні" (VIP-столики, дорогі позиції, без акцій). */
public class FineDiningFactory implements VenueFactory {
    @Override public Table createTable(int number, int seats) { return new VipTable(number, seats, 300); }
    @Override public Dish createMainDish() { return new Dish("Стейк Рібай", 950, 300); }
    @Override public Drink createDrink() { return new Drink("Шампанське (келих)", 420, 150, true); }
    @Override public DiscountPolicy createDiscountPolicy() { return new NoDiscount(); }
}
