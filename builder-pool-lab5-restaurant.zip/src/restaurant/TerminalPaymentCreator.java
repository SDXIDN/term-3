package restaurant;

/** Factory Method (ЛР №4) + Object Pool: творець, що видає шлюзи оплати з спільним пулом терміналів. */
public class TerminalPaymentCreator extends PaymentCreator {
    private final ObjectPool<PaymentTerminal> pool;

    public TerminalPaymentCreator(ObjectPool<PaymentTerminal> pool) { this.pool = pool; }

    @Override public PaymentGateway createGateway() { return new TerminalPaymentGateway(pool); }
}
