package restaurant;

/**
 * SRP: оркеструє тільки процес бронювання (валідація, пошук столика, збереження, сповіщення).
 * DIP: усі залежності отримує через конструктор і використовує через абстракції.
 */
public class ReservationService {
    private final Restaurant restaurant;
    private final ReservationValidator validator;
    private final ReservationWriter writer;
    private final NotificationService notifications;

    public ReservationService(Restaurant restaurant, ReservationValidator validator,
                              ReservationWriter writer, NotificationService notifications) {
        this.restaurant = restaurant;
        this.validator = validator;
        this.writer = writer;
        this.notifications = notifications;
    }

    /** Просте бронювання без додаткових параметрів. */
    public Reservation reserve(Customer customer, int guests, TimeSlot slot) {
        if (!validator.isValid(guests, slot)) return null;
        Table table = restaurant.findAvailableTable(guests, slot);
        return finish(customer, guests, slot, table, "звичайний візит");
    }

    /** Бронювання за запитом, створеним {@link ReservationRequestBuilder} (Builder). */
    public Reservation reserve(ReservationRequest request) {
        if (!validator.isValid(request.getGuests(), request.getSlot())) return null;
        Table table = request.isVipOnly()
                ? restaurant.findAvailableVipTable(request.getGuests(), request.getSlot())
                : restaurant.findAvailableTable(request.getGuests(), request.getSlot());
        return finish(request.getCustomer(), request.getGuests(), request.getSlot(), table,
                request.getOccasion() + (request.getNotes().isEmpty() ? "" : " (" + request.getNotes() + ")"));
    }

    private Reservation finish(Customer customer, int guests, TimeSlot slot, Table table, String details) {
        if (table == null) {
            System.out.println("[ReservationService] Відповідних вільних столиків немає для " + guests + " гостей");
            return null;
        }
        Reservation r = restaurant.createReservation(customer, table, slot, guests);
        writer.save(r);
        AuditLog.INSTANCE.log("Створено бронювання: столик №" + table.getNumber()
                + ", гостей " + guests + ", " + details);
        notifications.notifyReservationConfirmed(r);
        return r;
    }
}
