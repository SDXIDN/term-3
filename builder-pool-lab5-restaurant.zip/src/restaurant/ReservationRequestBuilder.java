package restaurant;

/**
 * Builder: покроково збирає {@link ReservationRequest} через fluent-інтерфейс.
 * Обов'язкові параметри (клієнт, кількість гостей, час) перевіряються в {@link #build()};
 * решта має значення за замовчуванням.
 */
public class ReservationRequestBuilder {
    Customer customer;
    int guests;
    TimeSlot slot;
    String occasion = "звичайний візит";
    int childSeats = 0;
    boolean windowSeat = false;
    boolean vipOnly = false;
    String notes = "";

    public ReservationRequestBuilder customer(Customer customer) { this.customer = customer; return this; }
    public ReservationRequestBuilder guests(int guests) { this.guests = guests; return this; }
    public ReservationRequestBuilder slot(TimeSlot slot) { this.slot = slot; return this; }
    public ReservationRequestBuilder occasion(String occasion) { this.occasion = occasion; return this; }
    public ReservationRequestBuilder childSeats(int childSeats) { this.childSeats = childSeats; return this; }
    public ReservationRequestBuilder windowSeat(boolean windowSeat) { this.windowSeat = windowSeat; return this; }
    public ReservationRequestBuilder vipOnly(boolean vipOnly) { this.vipOnly = vipOnly; return this; }
    public ReservationRequestBuilder notes(String notes) { this.notes = notes; return this; }

    /** Скидає білдер до початкового стану, щоб повторно використати його. */
    public ReservationRequestBuilder reset() {
        customer = null; guests = 0; slot = null; occasion = "звичайний візит";
        childSeats = 0; windowSeat = false; vipOnly = false; notes = "";
        return this;
    }

    /**
     * Валідує накопичені параметри й створює продукт.
     *
     * @throws IllegalStateException якщо не задано обов'язкові параметри або вони суперечливі
     */
    public ReservationRequest build() {
        if (customer == null) throw new IllegalStateException("Не вказано клієнта");
        if (slot == null) throw new IllegalStateException("Не вказано час бронювання");
        if (guests <= 0) throw new IllegalStateException("Кількість гостей має бути більшою за 0");
        if (childSeats > guests) throw new IllegalStateException("Дитячих стільців не може бути більше, ніж гостей");
        return new ReservationRequest(this);
    }
}
