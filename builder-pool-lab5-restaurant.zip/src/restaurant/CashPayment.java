package restaurant;

/** Оплата готівкою (заглушка). */
public class CashPayment implements PaymentGateway {
    @Override public void pay(Customer customer, double amount) {
        System.out.printf("[CashPayment.pay] customer=%s, amount=%.2f%n", customer.getName(), amount);
    }
}
