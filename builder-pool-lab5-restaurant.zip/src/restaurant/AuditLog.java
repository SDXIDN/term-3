package restaurant;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Singleton (enum-варіант): журнал аудиту подій системи.
 * Enum-синглтон безпечний щодо багатопотоковості, серіалізації та рефлексії,
 * тому рекомендований у Java (Effective Java, Item 3).
 */
public enum AuditLog {
    INSTANCE;

    private final List<String> entries = Collections.synchronizedList(new ArrayList<>());

    /** Додає запис до журналу. */
    public void log(String event) {
        entries.add(event);
        System.out.println("[AuditLog] " + event);
    }

    /** @return кількість записів. */
    public int size() { return entries.size(); }
}
