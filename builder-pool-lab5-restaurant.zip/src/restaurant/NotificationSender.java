package restaurant;

/** Інтерфейс каналу сповіщень (Low Coupling: решта системи залежить лише від нього). */
public interface NotificationSender {
    void send(String recipient, String message);
}
