# ЛР №5. Породжувальні шаблони: Builder і Object Pool

Розширення проєкту з ЛР №1-4 на тій самій предметній області «Бронювання столиків і харчування».

Компіляція: `javac -encoding UTF-8 -d out src/restaurant/*.java`
Запуск: `java -Dfile.encoding=UTF-8 -cp out restaurant.Main`
Javadoc: `javadoc -encoding UTF-8 -charset UTF-8 -private -d docs src/restaurant/*.java`

## Builder
| Роль | Клас |
|---|---|
| Продукт | ReservationRequest (незмінний, багато необов'язкових параметрів), Order |
| Builder | ReservationRequestBuilder (fluent API, reset(), валідація в build()), OrderBuilder |
| Director | ReservationRequestDirector: готові сценарії birthday, businessLunch, romanticDinner |
| Клієнт | Main, BookingController.reserveTable(ReservationRequest), ReservationService.reserve(ReservationRequest) |

Обов'язкові параметри (клієнт, гості, час) перевіряються в build(), а некоректні запити відхиляються
IllegalStateException. Запит з vipOnly=true обслуговується лише VIP-столиками (Restaurant.findAvailableVipTable).

## Object Pool
| Роль | Клас |
|---|---|
| Пул | ObjectPool<T>: потокобезпечний, ліниве створення до maxSize, acquire/release, очікування при вичерпанні |
| Pooled-об'єкт | PaymentTerminal (дорога ініціалізація, обмежена кількість) |
| Клієнт пулу | TerminalPaymentGateway (acquire у try, release у finally) |
| Інтеграція з Factory Method (ЛР №4) | TerminalPaymentCreator видає шлюзи зі спільним пулом |

Сценарії в Main: послідовні платежі повторно використовують єдиний термінал; 4 паралельні потоки при ліміті
в 2 термінали: створюються лише 2 об'єкти, решта потоків очікує повернення.

## Зауваження
Пул скидає стан об'єкта перед поверненням (PaymentTerminal.reset), щоб дані одного платежу не потрапили в інший.
