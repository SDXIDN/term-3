# ЛР №1. Принципи GRASP: бронювання столиків і харчування

Компіляція: `javac -encoding UTF-8 -d out src/restaurant/*.java`
Запуск: `java -Dfile.encoding=UTF-8 -cp out restaurant.Main`
Javadoc: `javadoc -encoding UTF-8 -charset UTF-8 -private -d docs src/restaurant/*.java`

| Принцип | Де в коді |
|---|---|
| Information Expert | Order.calculateTotal, OrderItem.getSubtotal, Table.isAvailable, Restaurant.findAvailableTable, TimeSlot.overlaps |
| Creator | Order створює OrderItem; Restaurant створює Table, MenuItem, Reservation |
| Controller | BookingController |
| Low Coupling | контролер залежить від інтерфейсів PaymentGateway, NotificationSender, DiscountPolicy |
| High Cohesion | кожен клас має одну задачу (Customer, Table, TimeSlot, MenuItem тощо) |
| Polymorphism | DiscountPolicy: NoDiscount, LoyaltyDiscount, LargeOrderDiscount; PaymentGateway: CardPayment, CashPayment |
| Pure Fabrication | BillingService |
| Indirection | NotificationService між контролером і SmsSender |
| Protected Variations | PaymentGateway, NotificationSender, DiscountPolicy |
