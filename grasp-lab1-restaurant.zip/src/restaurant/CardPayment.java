package restaurant;

/** Оплата карткою (заглушка). */
public class CardPayment implements PaymentGateway {
    @Override public void pay(Customer customer, double amount) {
        System.out.printf("[CardPayment.pay] customer=%s, amount=%.2f%n", customer.getName(), amount);
    }
}
