package restaurant;

/**
 * Рядок замовлення. Створюється лише класом {@link Order} (GRASP Creator).
 * Сам знає свою вартість (GRASP Information Expert).
 */
public class OrderItem {
    private final MenuItem menuItem;
    private final int quantity;

    OrderItem(MenuItem menuItem, int quantity) { // package-private: створює лише Order
        this.menuItem = menuItem;
        this.quantity = quantity;
    }

    public MenuItem getMenuItem() { return menuItem; }
    public int getQuantity() { return quantity; }

    /** Information Expert: ціна й кількість лежать у цьому класі. */
    public double getSubtotal() { return menuItem.getPrice() * quantity; }
}
