package restaurant;

import java.util.ArrayList;
import java.util.List;

/**
 * Заклад. Creator: агрегує та створює {@link Table} і {@link Reservation}.
 * Information Expert: володіє списком столиків, тому сам шукає вільний.
 */
public class Restaurant {
    private final String name;
    private final List<Table> tables = new ArrayList<>();
    private final List<MenuItem> menu = new ArrayList<>();

    public Restaurant(String name) { this.name = name; }

    public Table addTable(int number, int seats) {          // Creator
        Table t = new Table(number, seats);
        tables.add(t);
        return t;
    }

    public MenuItem addMenuItem(String itemName, double price) { // Creator
        MenuItem m = new MenuItem(itemName, price);
        menu.add(m);
        return m;
    }

    /** Information Expert: шукає найменший вільний столик, що вміщує гостей. */
    public Table findAvailableTable(int guests, TimeSlot slot) {
        Table best = null;
        for (Table t : tables) {
            if (t.getSeats() >= guests && t.isAvailable(slot)
                    && (best == null || t.getSeats() < best.getSeats())) {
                best = t;
            }
        }
        return best;
    }

    /** Creator: створює бронювання та реєструє його у столика. */
    public Reservation createReservation(Customer c, Table t, TimeSlot slot, int guests) {
        Reservation r = new Reservation(c, t, slot, guests);
        t.addReservation(r);
        return r;
    }

    public String getName() { return name; }
}
