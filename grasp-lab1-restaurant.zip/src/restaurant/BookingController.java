package restaurant;

/**
 * Controller: єдина точка входу для use-case'ів «забронювати столик» і «оформити та оплатити замовлення».
 * Сама бізнес-логіку не виконує, а лише координує: делегує {@link Restaurant}, {@link BillingService},
 * {@link PaymentGateway} і {@link NotificationService}. Залежить від абстракцій (Low Coupling).
 */
public class BookingController {
    private final Restaurant restaurant;
    private final BillingService billing;
    private final PaymentGateway payment;
    private final NotificationService notifications;

    public BookingController(Restaurant restaurant, BillingService billing,
                             PaymentGateway payment, NotificationService notifications) {
        this.restaurant = restaurant;
        this.billing = billing;
        this.payment = payment;
        this.notifications = notifications;
    }

    /** Use-case 1: бронювання столика. */
    public Reservation reserveTable(Customer customer, int guests, TimeSlot slot) {
        Table table = restaurant.findAvailableTable(guests, slot);
        if (table == null) {
            System.out.println("[BookingController] Вільних столиків немає для " + guests + " гостей");
            return null;
        }
        Reservation r = restaurant.createReservation(customer, table, slot, guests);
        notifications.notifyReservationConfirmed(r);
        return r;
    }

    /** Use-case 2: розрахунок і оплата замовлення. */
    public void checkout(Order order) {
        double amount = billing.calculateFinalAmount(order);
        payment.pay(order.getReservation().getCustomer(), amount);
        notifications.notifyPaid(order.getReservation().getCustomer(), amount);
    }
}
