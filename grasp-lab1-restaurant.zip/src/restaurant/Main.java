package restaurant;

import java.time.LocalDateTime;
import java.util.Arrays;

/** Демонстрація принципів GRASP на предметній області «Бронювання столиків і харчування». */
public class Main {
    public static void main(String[] args) {
        Restaurant restaurant = new Restaurant("Смак Буковини");
        restaurant.addTable(1, 2);
        restaurant.addTable(2, 4);
        restaurant.addTable(3, 8);
        MenuItem borscht = restaurant.addMenuItem("Борщ", 120);
        MenuItem steak = restaurant.addMenuItem("Стейк", 650);
        MenuItem wine = restaurant.addMenuItem("Вино (келих)", 180);

        BookingController controller = new BookingController(
                restaurant,
                new BillingService(Arrays.asList(new LoyaltyDiscount(), new LargeOrderDiscount())),
                new CardPayment(),
                new NotificationService(new SmsSender()));

        Customer ivan = new Customer("Іван", "+380501112233", true);
        TimeSlot slot = new TimeSlot(LocalDateTime.of(2026, 12, 5, 19, 0), 120);

        Reservation r1 = controller.reserveTable(ivan, 3, slot);          // -> столик №2
        Reservation r2 = controller.reserveTable(ivan, 3, slot);          // -> столик №3 (№2 зайнятий)
        Reservation r3 = controller.reserveTable(ivan, 12, slot);         // -> немає місць

        Order order = new Order(r1);
        order.addItem(borscht, 3);
        order.addItem(steak, 2);
        order.addItem(wine, 3);
        controller.checkout(order);
    }
}
