package restaurant;

/** Страва. LSP: підтип {@link MenuItem}, ціна рахується так само, тому безпечно підставляється в Order. */
public class Dish extends MenuItem {
    private final int weightGrams;

    public Dish(String name, double price, int weightGrams) {
        super(name, price);
        this.weightGrams = weightGrams;
    }

    public int getWeightGrams() { return weightGrams; }
}
