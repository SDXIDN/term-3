package restaurant;

/** SRP: єдина відповідальність - перевірка коректності запиту на бронювання. */
public class ReservationValidator {
    public boolean isValid(int guests, TimeSlot slot) {
        boolean ok = guests > 0 && slot != null;
        System.out.println("[ReservationValidator.isValid] guests=" + guests + " -> " + ok);
        return ok;
    }
}
