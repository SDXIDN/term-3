package restaurant;

/**
 * Controller (GRASP) і тонкий координатор. SRP: не містить бізнес-логіки, лише делегує
 * {@link ReservationService}, {@link BillingService}, {@link PaymentGateway}, {@link NotificationService}.
 */
public class BookingController {
    private final ReservationService reservations;
    private final BillingService billing;
    private final PaymentGateway payment;
    private final NotificationService notifications;

    public BookingController(ReservationService reservations, BillingService billing,
                             PaymentGateway payment, NotificationService notifications) {
        this.reservations = reservations;
        this.billing = billing;
        this.payment = payment;
        this.notifications = notifications;
    }

    public Reservation reserveTable(Customer customer, int guests, TimeSlot slot) {
        return reservations.reserve(customer, guests, slot);
    }

    /** @return сума до сплати після знижок. */
    public double checkout(Order order) {
        double amount = billing.calculateFinalAmount(order);
        payment.pay(order.getReservation().getCustomer(), amount);
        notifications.notifyPaid(order.getReservation().getCustomer(), amount);
        return amount;
    }
}
