package restaurant;

/** Напій. LSP: підтип {@link MenuItem} без зміни контракту getPrice(). */
public class Drink extends MenuItem {
    private final int volumeMl;
    private final boolean alcoholic;

    public Drink(String name, double price, int volumeMl, boolean alcoholic) {
        super(name, price);
        this.volumeMl = volumeMl;
        this.alcoholic = alcoholic;
    }

    public int getVolumeMl() { return volumeMl; }
    public boolean isAlcoholic() { return alcoholic; }
}
