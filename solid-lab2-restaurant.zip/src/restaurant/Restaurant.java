package restaurant;

import java.util.ArrayList;
import java.util.List;

/**
 * Заклад. Creator: агрегує та створює {@link Table} і {@link Reservation}.
 * Information Expert: володіє списком столиків, тому сам шукає вільний.
 */
public class Restaurant {
    private final String name;
    private final List<Table> tables = new ArrayList<>();
    private final List<MenuItem> menu = new ArrayList<>();

    public Restaurant(String name) { this.name = name; }

    public Table addTable(int number, int seats) {          // Creator
        Table t = new Table(number, seats);
        tables.add(t);
        return t;
    }

    public MenuItem addMenuItem(String itemName, double price) { // Creator
        MenuItem m = new MenuItem(itemName, price);
        menu.add(m);
        return m;
    }

    /** Information Expert: шукає найменший вільний столик, що вміщує гостей. */
    public Table findAvailableTable(int guests, TimeSlot slot) {
        Table best = null;
        for (Table t : tables) {
            if (t.getSeats() >= guests && t.isAvailable(slot)
                    && (best == null || t.getSeats() < best.getSeats())) {
                best = t;
            }
        }
        return best;
    }

    /** Creator: створює бронювання та реєструє його у столика. */
    public Reservation createReservation(Customer c, Table t, TimeSlot slot, int guests) {
        Reservation r = new Reservation(c, t, slot, guests);
        t.addReservation(r);
        return r;
    }

    /** Creator: створює VIP-столик (підтип Table, LSP). */
    public Table addVipTable(int number, int seats, double deposit) {
        Table t = new VipTable(number, seats, deposit);
        tables.add(t);
        return t;
    }

    /** Creator: створює страву (підтип MenuItem, LSP). */
    public MenuItem addDish(String itemName, double price, int weightGrams) {
        MenuItem m = new Dish(itemName, price, weightGrams);
        menu.add(m);
        return m;
    }

    /** Creator: створює напій (підтип MenuItem, LSP). */
    public MenuItem addDrink(String itemName, double price, int volumeMl, boolean alcoholic) {
        MenuItem m = new Drink(itemName, price, volumeMl, alcoholic);
        menu.add(m);
        return m;
    }

    public String getName() { return name; }
}
