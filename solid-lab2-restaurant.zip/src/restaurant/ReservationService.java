package restaurant;

/**
 * SRP: оркеструє тільки процес бронювання (валідація, пошук столика, збереження, сповіщення).
 * DIP: усі залежності отримує через конструктор і використовує через абстракції
 * ({@link ReservationWriter}); конкретні реалізації обирає композиційний корінь (Main).
 */
public class ReservationService {
    private final Restaurant restaurant;
    private final ReservationValidator validator;
    private final ReservationWriter writer;
    private final NotificationService notifications;

    public ReservationService(Restaurant restaurant, ReservationValidator validator,
                              ReservationWriter writer, NotificationService notifications) {
        this.restaurant = restaurant;
        this.validator = validator;
        this.writer = writer;
        this.notifications = notifications;
    }

    public Reservation reserve(Customer customer, int guests, TimeSlot slot) {
        if (!validator.isValid(guests, slot)) return null;
        Table table = restaurant.findAvailableTable(guests, slot);
        if (table == null) {
            System.out.println("[ReservationService] Вільних столиків немає для " + guests + " гостей");
            return null;
        }
        Reservation r = restaurant.createReservation(customer, table, slot, guests);
        writer.save(r);
        notifications.notifyReservationConfirmed(r);
        return r;
    }
}
