package restaurant;

import java.time.LocalDateTime;
import java.util.Arrays;

/** Демонстрація принципів SOLID. Тут же композиційний корінь (DIP): вибір конкретних реалізацій. */
public class Main {
    public static void main(String[] args) {
        Restaurant restaurant = new Restaurant("Смак Буковини");
        restaurant.addTable(1, 2);
        restaurant.addTable(2, 4);
        restaurant.addVipTable(3, 8, 500);                      // LSP: VipTable поводиться як Table
        MenuItem borscht = restaurant.addDish("Борщ", 120, 350);
        MenuItem steak = restaurant.addDish("Стейк", 650, 300);
        MenuItem wine = restaurant.addDrink("Вино (келих)", 180, 150, true);

        // DIP: залежності підставляються ззовні, сервіси знають лише абстракції
        ReservationRepository repository = new InMemoryReservationRepository();
        NotificationService notifications = new NotificationService(new SmsSender());
        ReservationService reservationService = new ReservationService(
                restaurant, new ReservationValidator(), repository, notifications);

        // OCP: HappyHourDiscount додано до списку без змін BillingService
        BillingService billing = new BillingService(Arrays.asList(
                new LoyaltyDiscount(), new LargeOrderDiscount(), new HappyHourDiscount()));

        CardPayment card = new CardPayment();
        BookingController controller = new BookingController(reservationService, billing, card, notifications);

        Customer ivan = new Customer("Іван", "+380501112233", true);
        TimeSlot slot = new TimeSlot(LocalDateTime.of(2026, 12, 5, 16, 0), 120); // у "щасливу годину"

        Reservation r1 = controller.reserveTable(ivan, 3, slot);   // столик №2
        Reservation r2 = controller.reserveTable(ivan, 3, slot);   // VIP-столик №3
        System.out.println("[LSP] столик r2 є VipTable: " + (r2.getTable() instanceof VipTable)
                + ", працює через базовий тип Table, isAvailable(slot)=" + r2.getTable().isAvailable(slot));
        controller.reserveTable(ivan, 12, slot);                   // немає місць
        controller.reserveTable(ivan, 0, slot);                    // SRP: валідатор відхиляє

        Order order = new Order(r1);
        order.addItem(borscht, 3);
        order.addItem(steak, 2);
        order.addItem(wine, 3);
        double amount = controller.checkout(order);

        System.out.print(new ReceiptFormatter().format(order, amount));   // SRP: форматування окремо

        // ISP: сервісу повернення потрібна лише Refundable; готівка (CashPayment) його не реалізує
        new RefundService(card).refundOrder(ivan, amount);
        PaymentGateway cash = new CashPayment();
        System.out.println("[ISP] CashPayment підтримує повернення: " + (cash instanceof Refundable));

        // ISP: звіту достатньо інтерфейсу лише для читання
        ReservationReader reader = repository;
        System.out.println("[ISP] бронювань клієнта: " + reader.findByCustomer(ivan).size());
    }
}
