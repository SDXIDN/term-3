# ЛР №2. Принципи SOLID: бронювання столиків і харчування

Розширення проєкту з ЛР №1 (GRASP) на тій самій предметній області.

Компіляція: `javac -encoding UTF-8 -d out src/restaurant/*.java`
Запуск: `java -Dfile.encoding=UTF-8 -cp out restaurant.Main`
Javadoc: `javadoc -encoding UTF-8 -charset UTF-8 -private -d docs src/restaurant/*.java`

| Принцип | Де в коді |
|---|---|
| SRP | ReservationValidator (валідація), ReceiptFormatter (чек), ReservationService (процес бронювання), BillingService (розрахунок), BookingController (лише координація) |
| OCP | HappyHourDiscount додано без змін BillingService/DiscountPolicy; нові способи оплати й сповіщень додаються так само |
| LSP | VipTable підміняє Table; Dish і Drink підміняють MenuItem у Order та Restaurant |
| ISP | Refundable окремо від PaymentGateway (CashPayment не зобов'язаний вміти refund); ReservationReader і ReservationWriter замість одного "товстого" сховища |
| DIP | ReservationService і RefundService залежать від абстракцій (ReservationWriter, NotificationService, Refundable); конкретні класи обирає Main (композиційний корінь) |
